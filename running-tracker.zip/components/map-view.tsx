"use client"

import { useEffect, useRef } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

interface Position {
  latitude: number
  longitude: number
  timestamp: number
}

interface MapViewProps {
  positions: Position[]
  className?: string
  height?: string
}

export default function MapView({ positions, className = "", height = "300px" }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<L.Map | null>(null)
  const polylineRef = useRef<L.Polyline | null>(null)

  useEffect(() => {
    // Fix for Leaflet icon issues in Next.js
    if (typeof window !== "undefined") {
      // Only run this on the client side
      delete L.Icon.Default.prototype._getIconUrl
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
        iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
        shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
      })
    }
  }, [])

  useEffect(() => {
    if (!mapRef.current || typeof window === "undefined") return

    // Initialize map if it doesn't exist
    if (!mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapRef.current).setView([0, 0], 13)
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(mapInstanceRef.current)
    }

    // If we have positions, update the map
    if (positions.length > 0) {
      const latLngs = positions.map((pos) => [pos.latitude, pos.longitude] as [number, number])

      // Remove existing polyline if it exists
      if (polylineRef.current && mapInstanceRef.current) {
        polylineRef.current.remove()
      }

      // Create new polyline
      if (mapInstanceRef.current) {
        polylineRef.current = L.polyline(latLngs, { color: "green", weight: 5 }).addTo(mapInstanceRef.current)

        // Add start and end markers if we have at least one position
        if (latLngs.length > 0) {
          // Start marker
          L.marker(latLngs[0]).addTo(mapInstanceRef.current).bindPopup("Start").openPopup()

          // End marker if we have more than one position
          if (latLngs.length > 1) {
            L.marker(latLngs[latLngs.length - 1])
              .addTo(mapInstanceRef.current)
              .bindPopup("Current Position")
          }

          // Fit the map to the bounds of the route
          mapInstanceRef.current.fitBounds(latLngs)
        }
      }
    }

    // Cleanup function
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [positions])

  // Force map to update its size when it becomes visible
  useEffect(() => {
    if (mapInstanceRef.current) {
      setTimeout(() => {
        mapInstanceRef.current?.invalidateSize()
      }, 100)
    }
  }, [])

  return <div ref={mapRef} className={`${className}`} style={{ height }} />
}
