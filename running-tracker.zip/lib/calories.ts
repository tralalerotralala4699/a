// Calculate calories burned based on weight, distance, and duration
export function calculateCaloriesBurned(weightKg: number, distanceKm: number, durationHours: number): number {
  // MET value for running (varies by speed)
  // Using an average MET value of 7 for moderate running
  const MET = 7

  // Calories = MET * weight in kg * duration in hours
  return MET * weightKg * durationHours
}

// Convert kg to lb
export function kgToLb(kg: number): number {
  return kg * 2.20462
}

// Convert lb to kg
export function lbToKg(lb: number): number {
  return lb / 2.20462
}
