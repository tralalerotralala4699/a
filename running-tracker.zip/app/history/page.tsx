"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { format } from "date-fns"
import { ArrowLeft, Calendar, Trash2, Map } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import dynamic from "next/dynamic"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

// Dynamically import the MapView component with no SSR
const MapView = dynamic(() => import("@/components/map-view"), {
  ssr: false,
  loading: () => <div className="h-[200px] bg-muted flex items-center justify-center">Loading map...</div>,
})

interface Position {
  latitude: number
  longitude: number
  timestamp: number
}

interface RunData {
  id: string
  date: string
  distance: number
  duration: number
  calories: number
  path: Position[]
}

export default function HistoryPage() {
  const [runs, setRuns] = useState<RunData[]>([])
  const [totalDistance, setTotalDistance] = useState(0)
  const [totalCalories, setTotalCalories] = useState(0)
  const [expandedRunId, setExpandedRunId] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Load run history from localStorage
    const runHistoryJSON = localStorage.getItem("runHistory")
    if (runHistoryJSON) {
      const runHistory: RunData[] = JSON.parse(runHistoryJSON)
      setRuns(runHistory)

      // Calculate totals
      const distance = runHistory.reduce((total, run) => total + run.distance, 0)
      const calories = runHistory.reduce((total, run) => total + run.calories, 0)
      setTotalDistance(distance)
      setTotalCalories(calories)
    }
  }, [])

  const deleteRun = (id: string) => {
    const updatedRuns = runs.filter((run) => run.id !== id)
    setRuns(updatedRuns)
    localStorage.setItem("runHistory", JSON.stringify(updatedRuns))

    // Recalculate totals
    const distance = updatedRuns.reduce((total, run) => total + run.distance, 0)
    const calories = updatedRuns.reduce((total, run) => total + run.calories, 0)
    setTotalDistance(distance)
    setTotalCalories(calories)

    toast({
      title: "Run deleted",
      description: "The run has been removed from your history",
    })
  }

  // Format duration as MM:SS or HH:MM:SS
  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60

    if (hours > 0) {
      return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs
        .toString()
        .padStart(2, "0")}`
    }
    return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const toggleRunExpansion = (id: string) => {
    if (expandedRunId === id) {
      setExpandedRunId(null)
    } else {
      setExpandedRunId(id)
    }
  }

  return (
    <div className="container max-w-md mx-auto py-8 px-4">
      <div className="flex items-center mb-6">
        <Link href="/" className="mr-4">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Run History</h1>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Your Stats</CardTitle>
          <CardDescription>Summary of all your runs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Total Distance</p>
              <p className="text-3xl font-bold">{totalDistance.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">kilometers</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Total Calories</p>
              <p className="text-3xl font-bold">{Math.round(totalCalories)}</p>
              <p className="text-xs text-muted-foreground">kcal burned</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Recent Runs</h2>

        {runs.length === 0 ? (
          <div className="text-center py-8">
            <Calendar className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-medium">No runs yet</h3>
            <p className="mt-2 text-sm text-muted-foreground">Start tracking your first run to see it here.</p>
            <Button className="mt-4 bg-green-600 hover:bg-green-700">
              <Link href="/track">Start Running</Link>
            </Button>
          </div>
        ) : (
          runs.map((run) => (
            <Card key={run.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{format(new Date(run.date), "MMMM d, yyyy")}</CardTitle>
                    <CardDescription>{format(new Date(run.date), "h:mm a")}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleRunExpansion(run.id)}>
                      <Map className="h-4 w-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete this run?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete this run from your history.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteRun(run.id)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Distance</p>
                    <p className="text-lg font-bold">{run.distance.toFixed(2)}</p>
                    <p className="text-xs text-muted-foreground">km</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Duration</p>
                    <p className="text-lg font-bold">{formatDuration(run.duration)}</p>
                    <p className="text-xs text-muted-foreground">time</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Calories</p>
                    <p className="text-lg font-bold">{Math.round(run.calories)}</p>
                    <p className="text-xs text-muted-foreground">kcal</p>
                  </div>
                </div>

                {expandedRunId === run.id && run.path.length > 0 && (
                  <div className="mt-4">
                    <MapView positions={run.path} className="w-full rounded-md" height="200px" />
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
