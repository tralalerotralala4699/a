"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { Play, Pause, Save, RotateCcw, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import dynamic from "next/dynamic"

// Dynamically import the MapView component with no SSR
const MapView = dynamic(() => import("@/components/map-view"), {
  ssr: false,
  loading: () => <div className="h-[300px] bg-muted flex items-center justify-center">Loading map...</div>,
})

interface Position {
  latitude: number
  longitude: number
  timestamp: number
}

interface RunData {
  id: string
  date: string
  distance: number
  duration: number
  calories: number
  path: Position[]
}

export default function TrackPage() {
  const [isTracking, setIsTracking] = useState(false)
  const [duration, setDuration] = useState(0)
  const [distance, setDistance] = useState(0)
  const [calories, setCalories] = useState(0)
  const [positions, setPositions] = useState<Position[]>([])
  const [userWeight, setUserWeight] = useState(70) // Default weight in kg
  const [showMap, setShowMap] = useState(true)
  const watchId = useRef<number | null>(null)
  const timer = useRef<NodeJS.Timeout | null>(null)
  const { toast } = useToast()

  // Load user weight from localStorage if available
  useEffect(() => {
    const savedWeight = localStorage.getItem("userWeight")
    if (savedWeight) {
      setUserWeight(Number.parseFloat(savedWeight))
    }
  }, [])

  // Calculate distance between two coordinates using Haversine formula
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371 // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1)
    const dLon = deg2rad(lon2 - lon1)
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    const d = R * c // Distance in km
    return d
  }

  const deg2rad = (deg: number) => {
    return deg * (Math.PI / 180)
  }

  // Calculate calories burned based on weight, distance, and duration
  const calculateCalories = (weightKg: number, distanceKm: number, durationHours: number) => {
    // MET value for running (varies by speed, using average of 7)
    const MET = 7
    // Calories = MET * weight in kg * duration in hours
    return MET * weightKg * durationHours
  }

  const startTracking = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Error",
        description: "Geolocation is not supported by your browser",
        variant: "destructive",
      })
      return
    }

    setIsTracking(true)
    setPositions([])
    setDistance(0)
    setDuration(0)
    setCalories(0)

    // Start timer
    timer.current = setInterval(() => {
      setDuration((prev) => prev + 1)
    }, 1000)

    // Start tracking location
    watchId.current = navigator.geolocation.watchPosition(
      (position) => {
        const newPosition = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          timestamp: position.timestamp,
        }

        setPositions((prevPositions) => {
          const updatedPositions = [...prevPositions, newPosition]

          // Calculate new distance if we have at least two positions
          if (prevPositions.length > 0) {
            const lastPos = prevPositions[prevPositions.length - 1]
            const newDist = calculateDistance(
              lastPos.latitude,
              lastPos.longitude,
              newPosition.latitude,
              newPosition.longitude,
            )

            // Only add distance if it's reasonable (to filter out GPS jumps)
            if (newDist < 0.1) {
              // Less than 100 meters
              setDistance((prevDistance) => {
                const updatedDistance = prevDistance + newDist
                // Update calories based on new distance
                const durationHours = duration / 3600
                setCalories(calculateCalories(userWeight, updatedDistance, durationHours))
                return updatedDistance
              })
            }
          }

          return updatedPositions
        })
      },
      (error) => {
        toast({
          title: "Error",
          description: `Failed to get location: ${error.message}`,
          variant: "destructive",
        })
        stopTracking()
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: 5000,
      },
    )
  }

  const stopTracking = () => {
    if (watchId.current !== null) {
      navigator.geolocation.clearWatch(watchId.current)
      watchId.current = null
    }

    if (timer.current !== null) {
      clearInterval(timer.current)
      timer.current = null
    }

    setIsTracking(false)
  }

  const resetTracking = () => {
    stopTracking()
    setPositions([])
    setDistance(0)
    setDuration(0)
    setCalories(0)
  }

  const saveRun = () => {
    if (distance === 0) {
      toast({
        title: "Cannot save",
        description: "No distance recorded for this run",
        variant: "destructive",
      })
      return
    }

    // Get existing runs from localStorage
    const existingRunsJSON = localStorage.getItem("runHistory")
    const existingRuns: RunData[] = existingRunsJSON ? JSON.parse(existingRunsJSON) : []

    // Create new run data
    const newRun: RunData = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      distance,
      duration,
      calories,
      path: positions,
    }

    // Add new run to history
    const updatedRuns = [newRun, ...existingRuns]
    localStorage.setItem("runHistory", JSON.stringify(updatedRuns))

    toast({
      title: "Run saved",
      description: `Saved ${distance.toFixed(2)} km run to your history`,
    })

    resetTracking()
  }

  // Format duration as MM:SS or HH:MM:SS
  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60

    if (hours > 0) {
      return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs
        .toString()
        .padStart(2, "0")}`
    }
    return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (watchId.current !== null) {
        navigator.geolocation.clearWatch(watchId.current)
      }
      if (timer.current !== null) {
        clearInterval(timer.current)
      }
    }
  }, [])

  return (
    <div className="container max-w-md mx-auto py-8 px-4">
      <div className="flex items-center mb-6">
        <Link href="/" className="mr-4">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Track Your Run</h1>
      </div>

      {showMap && (
        <Card className="mb-6 overflow-hidden">
          <MapView positions={positions} className="w-full" height="300px" />
        </Card>
      )}

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Current Run</CardTitle>
          <CardDescription>Track your distance and calories burned</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Distance</p>
              <p className="text-2xl font-bold">{distance.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">km</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Duration</p>
              <p className="text-2xl font-bold">{formatDuration(duration)}</p>
              <p className="text-xs text-muted-foreground">time</p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Calories</p>
              <p className="text-2xl font-bold">{Math.round(calories)}</p>
              <p className="text-xs text-muted-foreground">kcal</p>
            </div>
          </div>

          {isTracking && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>GPS Signal</span>
                <span>Active</span>
              </div>
              <Progress value={80} className="h-2" />
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          {!isTracking ? (
            <>
              <Button onClick={startTracking} className="bg-green-600 hover:bg-green-700">
                <Play className="mr-2 h-4 w-4" />
                Start
              </Button>
              <Button onClick={resetTracking} variant="outline" disabled={distance === 0 && duration === 0}>
                <RotateCcw className="mr-2 h-4 w-4" />
                Reset
              </Button>
            </>
          ) : (
            <>
              <Button onClick={stopTracking} variant="destructive">
                <Pause className="mr-2 h-4 w-4" />
                Pause
              </Button>
              <Button onClick={saveRun} variant="outline">
                <Save className="mr-2 h-4 w-4" />
                Save
              </Button>
            </>
          )}
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tips</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>• Make sure GPS is enabled on your device</p>
          <p>• For better accuracy, run in open areas away from tall buildings</p>
          <p>• Keep your phone with you during the entire run</p>
          <p>• Update your weight in the profile page for accurate calorie calculations</p>
        </CardContent>
      </Card>
    </div>
  )
}
