"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/hooks/use-toast"

export default function ProfilePage() {
  const [weight, setWeight] = useState(70)
  const [weightUnit, setWeightUnit] = useState("kg")
  const [displayWeight, setDisplayWeight] = useState(70)
  const { toast } = useToast()

  useEffect(() => {
    // Load user settings from localStorage
    const savedWeight = localStorage.getItem("userWeight")
    const savedWeightUnit = localStorage.getItem("weightUnit")

    if (savedWeight) {
      const parsedWeight = Number.parseFloat(savedWeight)
      setWeight(parsedWeight)
      setDisplayWeight(parsedWeight)
    }

    if (savedWeightUnit) {
      setWeightUnit(savedWeightUnit)
    }
  }, [])

  useEffect(() => {
    // Convert weight when unit changes
    if (weightUnit === "lb" && localStorage.getItem("weightUnit") === "kg") {
      setDisplayWeight(Math.round(weight * 2.20462))
    } else if (weightUnit === "kg" && localStorage.getItem("weightUnit") === "lb") {
      setDisplayWeight(Math.round(weight / 2.20462))
    }
  }, [weightUnit, weight])

  const handleWeightChange = (value: number[]) => {
    setDisplayWeight(value[0])
  }

  const handleUnitChange = (value: string) => {
    setWeightUnit(value)
  }

  const saveProfile = () => {
    // Convert weight to kg for storage if needed
    let weightInKg = displayWeight
    if (weightUnit === "lb") {
      weightInKg = displayWeight / 2.20462
    }

    localStorage.setItem("userWeight", weightInKg.toString())
    localStorage.setItem("weightUnit", weightUnit)

    toast({
      title: "Profile saved",
      description: "Your profile has been updated successfully",
    })
  }

  return (
    <div className="container max-w-md mx-auto py-8 px-4">
      <div className="flex items-center mb-6">
        <Link href="/" className="mr-4">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Profile</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Information</CardTitle>
          <CardDescription>Update your profile for accurate calorie calculations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="weight">Weight ({weightUnit})</Label>
              <span className="text-sm text-muted-foreground">
                {displayWeight} {weightUnit}
              </span>
            </div>
            <Slider
              id="weight"
              min={weightUnit === "kg" ? 40 : 88}
              max={weightUnit === "kg" ? 150 : 330}
              step={1}
              value={[displayWeight]}
              onValueChange={handleWeightChange}
              className="py-4"
            />
          </div>

          <div className="space-y-2">
            <Label>Weight Unit</Label>
            <RadioGroup value={weightUnit} onValueChange={handleUnitChange} className="flex space-x-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="kg" id="kg" />
                <Label htmlFor="kg" className="font-normal">
                  Kilograms (kg)
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="lb" id="lb" />
                <Label htmlFor="lb" className="font-normal">
                  Pounds (lb)
                </Label>
              </div>
            </RadioGroup>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={saveProfile} className="w-full bg-green-600 hover:bg-green-700">
            <Save className="mr-2 h-4 w-4" />
            Save Profile
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
